<!DOCTYPE html>
<html lang="en">
<head>
  <link rel="stylesheet" href="table.css">  
 <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
 <style>
   .margin-50 {
    margin: 50px;
   }
 </style>   
</head>
<body class="bg-success">
        <input type="button" value="Details" class="margin-50 btn btn-danger">
            <table class="table table-hover table-striped m-3">
                <thead class="table-primary">
                    <tr>
                        <th class="p-3">id</th>
                        <th class="p-3">name</th>
                        <th class="p-3">designation</th>  
                    </tr>
                </thead>

                
                 <tr>
                <th>123</th>
                <th>william</th>
                <th>engineer</th> 
                 </tr>
                
               
                <tr>
                <th>321</th>
                <th>yash</th>
                <th>data analyst</th>  
                </tr>
               
                <tr>
               <th>213</th>
               <th>mike</th>
               <th> data specialist</th>  
                </tr>
                
               <tr>
               <th>147</th>
               <th>tyson</th>
               <th>database engineer</th>
               </tr>

               <tr>
                <th>789</th>
                <th>john</th>
                <th>system engineer</th>
                </tr>

                
                  
                </table>
    
    
</body>
</html>